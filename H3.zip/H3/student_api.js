const express = require('express')
const cors = require('cors');

const app = express();
const port = 3000;

const https = require('https');
const fs = require('fs');

// serve the API with signed certificate on 443 (SSL/HTTPS) port
const httpsServer = https.createServer({
  key: fs.readFileSync('privateKey.key'),
  cert: fs.readFileSync('certificate.crt'),
}, app);


// Where we will keep students for now
let students = [];

app.use(cors());

// Configuring express middleware
// helps us decode the body from an HTTP request (this is called body-parser)
// What the body-parser middleware will be doing is grabbing the HTTP body, decoding the information,
// and appending it to the req.body. From there, we can easily retrieve the information from a request.
app.use(express.urlencoded({ extended: false }));
app.use(express.json());


httpsServer.listen(443, () => {
    console.log('HTTPS Server running on port 443');
});

// create an endpoint (a route)  that will  take some json formatted data and create an element in out stutdents array
// CREATE
app.post('/student', (req, res) => {
    // Part 1 We will be coding here
    // Part 2
    const student = req.body;

    // Output the student data to the console for debugging
    console.log(student);
    students.push(student);

   res.send('Student is added to the database');
});

//create an endpoint to get all students from the API (READ)
app.get('/students', (req, res) => {
    res.json(students);

    //check results at https://jsonformatter.org/
});

//delete a student by id
app.delete('/student/:id', (req, res) => {
    // Reading id from the URL
    const id = req.params.id;

    // Remove item from the students array
    // filter() method creates a new array with all 
    // elements that pass the test implemented by the provided function.
    students = students.filter(i => {
        if (i.id !== id) {
            return true;
        }
        return false;
    });

    res.send('Student is deleted');
});

// Updating - editing a student - we want to use PUT
app.put('/student/:id', (req, res) => {
    // Reading id from the URL
    const id = req.params.id;
    const newStudent = req.body;

   // Update item from the students array
   for (let i = 0; i < students.length; i++) {
       let student = students[i]
       if (student.id === id) {
           students[i] = newStudent;
       }
   }

   res.send('Student is edited via PUT');
});

